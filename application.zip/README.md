# K-Music, Deleted kaiads and kaios 3 version cuz I dont use it also icons from the system apps

## An audio player for KaiOS with playlist manager **WELP I BROKE SOMETHING**
It doesnt find my files, I suspect I wrote the syntax wrong in app.js
## Licence

[MIT](https://opensource.org/licenses/MIT)

